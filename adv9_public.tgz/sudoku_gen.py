#!/usr/bin/env python3
import random,sys,json
N=9
def new_solved():
    board=[[0]*9 for _ in range(9)]
    def ok(r,c,v):
        for i in range(9):
            if board[r][i]==v or board[i][c]==v:return False
        br,bc=r//3*3,c//3*3
        for i in range(br,br+3):
            for j in range(bc,bc+3):
                if board[i][j]==v:return False
        return True
    def fill():
        for r in range(9):
            for c in range(9):
                if board[r][c]==0:
                    vals=list(range(1,10));random.shuffle(vals)
                    for v in vals:
                        if ok(r,c,v):
                            board[r][c]=v
                            if fill():return True
                            board[r][c]=0
                    return False
        return True
    fill()
    return board
def count_solutions(b,limit=2):
    cnt=[0]
    def ok2(g,r,c,v):
        for i in range(9):
            if g[r][i]==v or g[i][c]==v:return False
        br,bc=r//3*3,c//3*3
        for i in range(br,br+3):
            for j in range(bc,bc+3):
                if g[i][j]==v:return False
        return True
    def solve():
        for r in range(9):
            for c in range(9):
                if b[r][c]==0:
                    for v in range(1,10):
                        if ok2(b,r,c,v):
                            b[r][c]=v
                            solve()
                            b[r][c]=0
                            if cnt[0]>=limit:return
                    return
        cnt[0]+=1
    solve()
    return cnt[0]
def main():
    random.seed()
    solved=new_solved()
    cells=[(r,c) for r in range(9) for c in range(9)]
    random.shuffle(cells)
    puzzle=[row[:] for row in solved]
    removed=0
    target=46
    for (r,c) in cells:
        if removed>=target:break
        old=puzzle[r][c]
        puzzle[r][c]=0
        test=[row[:] for row in puzzle]
        if count_solutions(test,2)!=1:
            puzzle[r][c]=old
        else:
            removed+=1
    def flat(g):
        return ''.join(str(x) if x else '.' for row in g for x in row)
    sys.stdout.write(json.dumps({'board':flat(puzzle),'answer':flat(solved),'removed':removed}))
if __name__=='__main__':
    main()